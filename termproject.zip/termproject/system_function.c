#include <stdio.h>
#include <stdlib.h>

int main(void) {
	// execute external program
	printf("execute term_main_code\n");
	int exe = system("");
	printf("result : %d", exe);

	system("pause");
	return 0;
}