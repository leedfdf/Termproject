#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define WALKING_SPEED 1
#define KICKBOARD_SPEED 2
#define MAX 100

// time ���� kickboard ��ġ ����
// user_num throughpoint start_time path

struct User {
	char start_point;
	char through_point;
	char end_point;
	char* start_time;
	char* through_time;
	char* end_time;
	int distance;
	int* path;
};

// function protocol
void run(struct User*, int**, int*, int, int);
void time_spend(char*);
void print(struct User*, int);
void print_kick_location(char* time, int* kickboard_location, int location_num);

void find_kickboard(struct User* user, int j, int** location, int* kickboard_location, int location_num);
int minDistance(int dist[], int location_num, int check[]);
int dijkstra(int** location, char start_point, int location_num, int dest_index, int* path);
void printPath(int* parent, int j, int i, int location_num, int* real_path, int* count);

void timeCalculator(struct User* user, int j, int check, int distance);

void kickboard_update(int*, int, int);
void find_destination(struct User* user, int j, int** location, int location_num);

void copyarray(int* source, int* target, int size);
void swap(int* a, int* b);

int main(void)
{
	FILE* fp = fopen("src.txt", "r"); //read data file
	int location_num = 0, user_num; // a number of locations,a number of users
	int** location; // variable for  2_demension array about location(node) & distance(edge)
	int* kickboard_location; // variable for store kickboard in each location 
	struct User* user;

	fscanf(fp, "%d", &location_num);
	location = (int**)malloc(sizeof(int*) * location_num); // a number of location from file
	kickboard_location = (int*)malloc(sizeof(int) * location_num); //array for kick board
	for (int i = 0; i < location_num; i++) // allocate array space of location_num X location_num
	{
		location[i] = (int*)malloc(sizeof(int) * location_num); //allocate distance variable space
		for (int j = 0; j < location_num; j++)
		{
			fscanf(fp, "%d", &location[i][j]); //read all location data from file
		}
	}
	for (int i = 0; i < location_num; i++)
	{
		fscanf(fp, "%d", &kickboard_location[i]); //read all kickboard location
	}
	fscanf(fp, "%d", &user_num);
	user = malloc(sizeof(struct User) * user_num);

	for (int i = 0; i < user_num; i++)
	{
		user[i].start_time = (char*)malloc(sizeof(char) * 4);
		user[i].through_time = (char*)malloc(sizeof(char) * 4);
		user[i].end_time = (char*)malloc(sizeof(char) * 4);
		user[i].path = malloc(sizeof(int) * location_num);

		char* buf = malloc(sizeof(char) * 100);
		fscanf(fp, "%s", buf);
		strcpy(user[i].start_time, buf);

		fscanf(fp, " %c %c", &user[i].start_point, &user[i].end_point);

		user[i].through_point = "";
		user[i].through_time = "";
		user[i].end_time = "";
		user[i].distance = 0;

	}
	fclose(fp);
	run(user, location, kickboard_location, location_num, user_num);
	print(user, user_num);
	system("kickboard_simulator");
}

/* run the main code */
void run(struct User* user, int** location, int* kickboard_location, int location_num, int user_num)
{
	int checkend = 0, i = 0;	// checkend : check if the program end
	char* time = (char*)malloc(sizeof(char) * 4);

	strcpy(time, user[0].start_time); // copy user[0].start_time and time

	struct User user_started[10];	// save started users in array

	while (checkend == 0)
	{
		for (int j = 0; j < user_num; j++)
		{
			if (strcmp(user[j].start_time, time) == 0) // if user[j].start_time = time 
			{
				// find the closest kickboard location, through_time, through_point, path
				find_kickboard(user, j, location, kickboard_location, location_num);
				kickboard_update(kickboard_location, user[j].through_point - 97, -1); // update kickboard location
				user_started[i] = user[j];
				i++;
			}
		}

		for (int j = 0; j < i; j++)
		{
			if (strcmp(user_started[j].through_time, time) == 0)
			{
				find_destination(user, j, location, location_num); // find the path, end_time
				kickboard_update(kickboard_location, user[j].end_point - 97, 1); // update kickboard
			}
		}


		for (int j = 0; j < user_num; j++)
		{
			if (user[j].end_time == "")
			{
				checkend = 0;
				break;
			}
			else
			{
				checkend = 1;
			}
		}

		int check = 0;

		if (strcmp(user[0].start_time, time) == 0)
		{
			check = 0;	// if check = 0, file should open in WRITE mode
		}
		else
		{
			check = 1;	// if check = 1, file should open in APPEND mode
		}

		print_kick_location(time, kickboard_location, location_num, check);	// print the time and kickboard location

		time_spend(time);
	}
}

/*
����� kickboard ������ distance, path, through_point, through_time ���ϱ�
*/
void find_kickboard(struct User* user, int j, int** location, int* kickboard_location, int location_num) {
	/* ��� node - kickboard �� shortest path */
	int throughPoint = 0;
	int minDistance = MAX;

	/* kickboard �� �����ϴ� index / dijkstra */;
	for (int i = 0; i < location_num; i++)
	{
		if (kickboard_location[i] > 0) // kicboard �� �ִ� idx ã�� (i = kickboard �� �ִ� idx)
		{
			int* current_path = (int*)malloc(sizeof(int) * location_num);

			int result = dijkstra(location, user[j].start_point, location_num, i, current_path);	// find the shortest distance to kickboard

			if (minDistance > result)
			{
				minDistance = result;
				throughPoint = i;

				copyarray(current_path, user[j].path, location_num);	// copy the current_path to user.path
			}
		}
	}
	user[j].through_point = (char)(throughPoint + 97);
	user[j].distance = minDistance;
	timeCalculator(user, j, 0, minDistance);	// calculate through_time
}

/* find the mindistance */
int minDistance(int dist[], int location_num, int check[]) {
	int min = MAX, min_index = 0;

	for (int i = 0; i < location_num; i++)
	{
		if (check[i] == 0 && min >= dist[i])
		{
			min_index = i;
			min = dist[i];
		}
	}

	return min_index;
}

/* dijkstra algorithm */
int dijkstra(int** location, char start_point, int location_num, int dest_index, int* current_path) {
	int check[MAX];	// visited node = 1/ not visited node = 0
	int dist[MAX];	// minimum distance from source to each node
	int src_index = start_point - 97;
	int* path = malloc(sizeof(int) * location_num);

	// initialization
	path[src_index] = -1;

	for (int i = 0; i < location_num; i++)
	{
		dist[i] = MAX;
		check[i] = 0;
	}

	dist[src_index] = 0;

	for (int count = 0; count < location_num - 1; count++)
	{
		int u = minDistance(dist, location_num, check);

		for (int i = 0; i < location_num; i++)
		{
			if (check[i] == 0 && dist[i] > dist[u] + location[u][i])
			{
				path[i] = u;	// save the predecessor node
				dist[i] = dist[u] + location[u][i];	// save the closest node
			}
		}

		check[u] = 1;
	}

	int count = 0;
	printPath(path, dest_index, 0, location_num, current_path, &count);	// print path

	for (int k = count; k > count / 2; k--)
	{
		swap(&current_path[k], &current_path[count - k]);	// swap the path to print path in order
	}

	return dist[dest_index];
}

// caculate path recursively
void printPath(int* parent, int j, int i, int location_num, int* real_path, int* count)
{
	// Base Case : If j is source
	if (parent[j] == -1)
	{
		for (int k = i; k < location_num; k++)
		{
			real_path[k] = -1;
		}
		return;
	}

	real_path[i] = j;	// save the predecessor node
	(*count)++;	// count the number of predecessor node

	printPath(parent, parent[j], i + 1, location_num, real_path, count);
	return;
}

/* update the location of kickboard*/
void kickboard_update(int* kickboard_location, int throughPoint, int check) {
	kickboard_location[throughPoint] += check;
}

/*
find the destination from kickboard location to destination
*/
void find_destination(struct User* user, int j, int** location, int location_num) {
	int dest_index = user[j].end_point - 97;
	int distance;
	int* current_path = (int*)malloc(sizeof(int) * location_num);
	distance = dijkstra(location, user[j].through_point, location_num, dest_index, current_path);

	// add current_path to user[j].path
	int m = 0;
	for (int i = 0; i < location_num; i++)
	{
		if (user[j].path[i] < 0)
		{
			*(user[j].path + i) = *(current_path + m);
			m++;
		}
	}

	timeCalculator(user, j, 1, distance);	// calculate end_time
	user[j].distance += distance;
}

// user->through_time = user->start_time + (WALKING_SPEED * minDistance); char ����...
// if check = 0, find through_time 
// if check = 1, find end_time
// (check = 0) distance -> kickboard_find ������ ����� kickboard distance
// (check = 1) distance -> destination_find ������ through_point ���� dest_point ������ distance
void timeCalculator(struct User* user, int j, int check, int distance) {
	char* t = (char*)malloc(sizeof(char) * 4);

	if (check == 0)
	{
		strcpy(t, user[j].start_time);
	}
	else
	{
		strcpy(t, user[j].through_time);
	}

	char hour[2] = { t[0],t[1] };
	char minute[2] = { t[2],t[3] };
	int h = atoi(hour);
	int m = atoi(minute);

	if (check == 0)
	{
		m += (WALKING_SPEED * distance);
	}
	else
	{
		m += (KICKBOARD_SPEED * distance);
	}

	while (m > 59)
	{
		if (m > 59)
		{
			h++;
			m -= 60;
		}
	}

	if (m > 9 && h > 9)
		sprintf(t, "%d%d", h, m);
	else if (h > 9)
		sprintf(t, "%d0%d", h, m);
	else if (m > 9)
		sprintf(t, "0%d%d", h, m);
	else
		sprintf(t, "0%d0%d", h, m);

	if (check == 0)
	{
		user[j].through_time = t;
	}
	else
	{
		user[j].end_time = t;
	}
}

// print the result to 'result.txt' file
void print(struct User* user, int user_num)
{
	// write file
	FILE* fp2 = fopen("user_result.txt", "w");

	fprintf(fp2, "%d\n", user_num);
	for (int i = 0; i < user_num; i++)
	{
		fprintf(fp2, "%d ", (char)(user[i].through_point - 96));
		fprintf(fp2, "%s ", user[i].start_time);
		fprintf(fp2, "%d", (char)(user[i].start_point - 96));
		for (int j = 0; j < 6; j++)
		{
			if (user[i].path[j] >= 0)
			{
				fprintf(fp2, "%d", (user[i].path[j] + 1));
			}
		}
		fprintf(fp2, "\n");

		// printf("\ndistance : %d\n", user[i].distance);
	}

	fclose(fp2);
}

// calculate the flow of time
void time_spend(char* t)
{
	char hour[2] = { t[0],t[1] };
	char minute[2] = { t[2],t[3] };
	int h = atoi(hour);
	int m = atoi(minute);
	if (m == 59)
	{
		h++;
		m = 0;
	}
	else
		m++;

	if (m > 9 && h > 9)
		sprintf(t, "%d%d", h, m);
	else if (h > 9)
		sprintf(t, "%d0%d", h, m);
	else if (m > 9)
		sprintf(t, "0%d%d", h, m);
	else
		sprintf(t, "0%d0%d", h, m);

}

// function to swap two element
void swap(int* a, int* b) {
	int tmp = *a;
	*a = *b;
	*b = tmp;
}

// function to copy source array to target array
void copyarray(int* source, int* target, int size)    // �Է°����� �ּҰ��� ���� (line 213)
{
	int i;

	for (i = 0; i < size; i++)
	{
		*(target + i) = *(source + i);        // *(target + i) = �ּҰ��� ������Ų��. (�迭�� ����ĭ���� �̵�)
	}
}

// print to kickboard_result.txt 
// information of kickboard per time
void print_kick_location(char* time, int* kickboard_location, int location_num, int check) {
	FILE* fp2;

	if (check == 0)
	{
		fp2 = fopen("kickboard_result.txt", "w");	// write file for first time
	}
	else
	{
		fp2 = fopen("kickboard_result.txt", "a");	// append file
	}

	// fprintf(fp2, "%s ", time);
	for (int i = 0; i < location_num; i++) {
		fprintf(fp2, "%d ", kickboard_location[i]);
	}
	fprintf(fp2, "\n");
	fclose(fp2);
}